/// <reference types="vitest" />

import path from 'path'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  test: {},
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
server: {
    host: true,       // Permet d'utiliser 0.0.0.0 pour l'accès dans Docker
    port: 3000,       // Définit le port 3000 par défaut (modifiable si nécessaire)
    strictPort: true, // Empêche Vite de changer de port si 3000 est occupé
    watch: {
      usePolling: true, // Utile dans Docker pour détecter les changements de fichiers
    },
  },
})



